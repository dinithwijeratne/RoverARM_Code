#!/bin/bash
# On the Orange Pi: start the serial driver (talks to the Pico) and the arm controller.
# The workspace has to be built first. It is looked for in ~/ros2_ws, or in the
# folder named in ROS2_WS.
WS="${ROS2_WS:-$HOME/ros2_ws}"
source /opt/ros/jazzy/setup.bash
source "$WS/install/setup.bash" || { echo "Build the workspace first: cd $WS && colcon build"; exit 1; }

ros2 run pico_relay relay &
trap 'kill $! 2>/dev/null' EXIT
ros2 run arm_controller controller
