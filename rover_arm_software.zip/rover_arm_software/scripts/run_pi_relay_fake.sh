#!/bin/bash
# No hardware: the arm controller plus a pretend Pico (instead of the serial driver).
# Needs the workspace built, same as run_pi_relay.sh.
WS="${ROS2_WS:-$HOME/ros2_ws}"
source /opt/ros/jazzy/setup.bash
source "$WS/install/setup.bash" || { echo "Build the workspace first: cd $WS && colcon build"; exit 1; }

ros2 run arm_controller fake_pico &
trap 'kill $! 2>/dev/null' EXIT
ros2 run arm_controller controller
