#!/bin/bash
# Real run on Linux: the base station talks to the Orange Pi over ROS2.
# Extra options are passed on, for example:  bash run_base_station.sh --link sim
cd "$(dirname "$0")/../baseStationCode"
[ -f /opt/ros/jazzy/setup.bash ] && source /opt/ros/jazzy/setup.bash
python3 -m base_station --link ros2 "$@"
