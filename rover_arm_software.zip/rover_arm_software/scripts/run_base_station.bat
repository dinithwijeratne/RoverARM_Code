@echo off
rem Starts the arm base station. Double-click for the fake-data test mode, or
rem pass options, for example:  run_base_station.bat --link serial --port COM5
cd /d "%~dp0..\baseStationCode"

rem Find Python: 3.12 first, then any Python from the launcher, then plain python.
set "PY="
where py >nul 2>nul && py -3.12 -c "import sys" >nul 2>nul && set "PY=py -3.12"
if not defined PY where py >nul 2>nul && set "PY=py"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python was not found.
  echo Install Python 3.12 from python.org and tick "Add python.exe to PATH".
  pause
  exit /b 1
)
echo Using: %PY%

rem This really loads Qt, not just checks that a folder exists.
set "CHECK=import yaml, numpy, pygame, pyqtgraph, serial; from PyQt5 import QtWidgets"

%PY% -c "%CHECK%" >nul 2>nul
if errorlevel 1 (
  echo Installing the libraries this needs. One time only, a few minutes.
  %PY% -m pip install -r requirements.txt
  %PY% -c "%CHECK%" >nul 2>nul
  if errorlevel 1 (
    echo Repairing the Qt install.
    %PY% -m pip install --force-reinstall PyQt5
  )
  %PY% -c "%CHECK%" >nul 2>nul
  if errorlevel 1 (
    echo.
    echo Setup did not finish. Send a screenshot of this window.
    pause
    exit /b 1
  )
)

if "%~1"=="" (set "ARGS=--link sim") else (set "ARGS=%*")
%PY% -m base_station %ARGS%
pause
