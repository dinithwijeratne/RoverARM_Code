@echo off
rem Base station straight to the Pico over USB (no Pi, no ROS2). Real commands
rem are sent, so the motor and servos CAN MOVE once you turn Arm output ON.
echo Plug the Pico in by USB first.
echo Find its port in Device Manager, under "Ports (COM and LPT)", for example COM5.
echo.
set /p PORT=Which port is the Pico on? 
if "%PORT%"=="" (
  echo No port given.
  pause
  exit /b 1
)
call "%~dp0run_base_station.bat" --link serial --port %PORT%
