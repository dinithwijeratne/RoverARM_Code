"""Side-view geometry for the arm display (no Qt, no ROS).

Everything here is *commanded* pose: the servos give no position feedback, so
this is where the arm should be, not a measurement of where it is.

Coordinates: +x is forward, +y is up, the shoulder pivot is the origin.
"""
import math
from dataclasses import dataclass


@dataclass(frozen=True)
class ArmPose:
    shoulder: tuple
    elbow: tuple
    wrist: tuple
    tip: tuple
    jaw_a: tuple
    jaw_b: tuple
    open_fraction: float      # 0 = gripper at its min angle, 1 = at its max angle
    link_angles_deg: tuple    # absolute drawn angle of each link, from horizontal


def _step(point, length, angle_deg):
    a = math.radians(angle_deg)
    return (point[0] + length * math.cos(a), point[1] + length * math.sin(a))


def compute_pose(targets, joints, view):
    """Work out where each joint is drawn.

    targets: joint name -> servo angle in degrees
    joints:  sequence of JointConfig (for home and range)
    view:    ArmViewConfig
    """
    by_name = {j.name: j for j in joints}

    def drawn(name, vj):
        return vj.home_display_deg + vj.direction * (
            targets[name] - by_name[name].home_deg)

    a1 = drawn("shoulder", view.shoulder)           # from horizontal
    a2 = a1 + drawn("elbow", view.elbow)            # relative to the shoulder link
    a3 = a2 + drawn("wrist", view.wrist)            # relative to the elbow link

    shoulder = (0.0, 0.0)
    elbow = _step(shoulder, view.shoulder.length, a1)
    wrist = _step(elbow, view.elbow.length, a2)
    tip = _step(wrist, view.wrist.length, a3)

    grip = by_name["end_effector"]
    span = grip.max_deg - grip.min_deg
    frac = max(0.0, min(1.0, (targets["end_effector"] - grip.min_deg) / span))
    half = frac * view.jaw_max_open_deg / 2.0
    return ArmPose(
        shoulder=shoulder, elbow=elbow, wrist=wrist, tip=tip,
        jaw_a=_step(tip, view.jaw_len, a3 + half),
        jaw_b=_step(tip, view.jaw_len, a3 - half),
        open_fraction=frac, link_angles_deg=(a1, a2, a3))
