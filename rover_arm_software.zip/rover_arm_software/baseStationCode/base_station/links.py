"""How the base station talks to the arm side.

SimLink   : no hardware. Makes up pressure/temperature data and counts the
            commands it is given. Used for testing on any computer.
SerialLink: straight to the Pico over USB serial, any OS (no Pi, no ROS).
RosLink   : real ROS2 link to the Orange Pi (Linux only, see ros_link.py).
"""
import math
import random
import threading
import time
from dataclasses import dataclass
from typing import Optional

from .joints import JOINT_ORDER
from .telemetry import SeriesHistory

SAMPLE_PERIOD_S = 0.2   # simulated telemetry rate: 5 Hz


@dataclass
class LinkSnapshot:
    kind: str                       # "sim" or "ros2"
    link_ok: bool                   # True when a real link is up
    link_text: str                  # one line for the status display
    pressure: tuple                 # (xs, [ys]) in kPa
    temperature: tuple              # (xs, [ys]) in deg C
    pressure_age_s: Optional[float]
    temperature_age_s: Optional[float]


class BaseLink:
    kind = "base"

    def send_command(self, targets_deg, force=False):
        """targets_deg: joint name -> degrees, except axis_0 which is motor
        percent. force=True is for stops: skip any rate limiting."""
        raise NotImplementedError

    def snapshot(self):
        raise NotImplementedError

    def close(self):
        pass


class SimLink(BaseLink):
    kind = "sim"

    def __init__(self, history_s, clock=time.monotonic, seed=None):
        self._clock = clock
        self._rng = random.Random(seed)
        self._t0 = clock()
        self._n = 0                      # samples made so far
        self._pressure = SeriesHistory(1, history_s)
        self._temperature = SeriesHistory(1, history_s)
        self.commands_sent = 0
        self.last_command = None

    def send_command(self, targets_deg, force=False):
        self.commands_sent += 1
        self.last_command = dict(targets_deg)

    def _advance(self, now):
        while self._t0 + self._n * SAMPLE_PERIOD_S <= now:
            rel = self._n * SAMPLE_PERIOD_S      # index based, so no float drift
            t = self._t0 + rel
            self._pressure.add(
                t, (100.2 + 0.05 * math.sin(0.2 * rel) + self._rng.gauss(0, 0.01),))
            self._temperature.add(
                t, (24.0 + 0.5 * math.sin(0.05 * rel) + self._rng.gauss(0, 0.02),))
            self._n += 1

    def snapshot(self):
        now = self._clock()
        self._advance(now)
        return LinkSnapshot(
            kind="sim", link_ok=False,
            link_text=f"SIMULATED, no ROS2 ({self.commands_sent} commands sent)",
            pressure=self._pressure.snapshot(now),
            temperature=self._temperature.snapshot(now),
            pressure_age_s=self._pressure.age(now),
            temperature_age_s=self._temperature.age(now))


class SerialLink(BaseLink):
    """Straight to the Pico over USB serial. No Orange Pi, no ROS, so it works
    on Windows too. This is the tethered test setup: the same M lines the Orange
    Pi sends to the Pico, see pico_protocol.py."""

    kind = "serial"

    def __init__(self, settings, port, baud=115200, serial_factory=None,
                 clock=time.monotonic):
        from .pico_bridge import SerialBridge    # only this mode needs it
        self._clock = clock
        self._port = port
        self._lock = threading.Lock()
        self._pressure = SeriesHistory(1, settings.history_s)
        self._temperature = SeriesHistory(1, settings.history_s)
        self._last_problem = ""
        self._bridge = SerialBridge(
            port, baud, on_telemetry=self._on_telemetry, on_event=self._on_event,
            serial_factory=serial_factory, send_rate_hz=settings.serial_send_hz,
            heartbeat_s=settings.serial_heartbeat_s, clock=clock)
        self._bridge.start()

    def _on_telemetry(self, tel):
        now = self._clock()
        with self._lock:
            self._pressure.add(now, (tel.pressure_pa / 1000.0,))      # Pa -> kPa
            self._temperature.add(now, (tel.temperature_c,))

    def _on_event(self, level, text):
        if level != "info":
            self._last_problem = text

    def send_command(self, targets_deg, force=False):
        self._bridge.send_command(
            targets_deg["axis_0"], [targets_deg[n] for n in JOINT_ORDER[1:]],
            force=force)

    def snapshot(self):
        now = self._clock()
        b = self._bridge
        if b.connected:
            text = (f"SERIAL {self._port}: connected ({b.commands_sent} sent, "
                    f"{b.telemetry_ok} readings, {b.telemetry_bad} bad lines)")
        else:
            text = f"SERIAL {self._port}: not connected"
            if self._last_problem:
                text += f" ({self._last_problem[:70]})"
        with self._lock:
            return LinkSnapshot(
                kind="serial", link_ok=b.connected, link_text=text,
                pressure=self._pressure.snapshot(now),
                temperature=self._temperature.snapshot(now),
                pressure_age_s=self._pressure.age(now),
                temperature_age_s=self._temperature.age(now))

    def close(self):
        self._bridge.stop()


def make_link(kind, settings, port=None, baud=115200):
    if kind == "sim":
        return SimLink(settings.history_s)
    if kind == "serial":
        if not port:
            raise ValueError("--link serial needs --port (for example COM5 or "
                             "/dev/ttyACM0)")
        return SerialLink(settings, port, baud)
    if kind == "ros2":
        from .ros_link import RosLink    # imports rclpy, so only when asked for
        return RosLink(settings)
    raise ValueError(f"unknown link kind '{kind}'")
