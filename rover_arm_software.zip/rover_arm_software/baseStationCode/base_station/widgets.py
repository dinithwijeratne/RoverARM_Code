"""Custom Qt widgets."""
from PyQt5 import QtCore, QtGui, QtWidgets

from .controller import ControllerState

ACCENT = QtGui.QColor("#1f6feb")
GREEN = QtGui.QColor("#1e8e3e")
RED = QtGui.QColor("#c5221f")
AMBER = QtGui.QColor("#b8720c")
BODY = QtGui.QColor("#e2e2e2")
EDGE = QtGui.QColor("#b5b5b5")
IDLE = QtGui.QColor("#cfcfcf")
TEXT = QtGui.QColor("#1a1a1a")
MUTED = QtGui.QColor("#6b6b6b")


class ControllerView(QtWidgets.QWidget):
    """Draws an Xbox-style controller showing what the app is reading right now."""

    W, H = 400.0, 240.0

    def __init__(self, parent=None):
        super().__init__(parent)
        self._state = ControllerState()
        self.setMinimumSize(280, 170)

    def sizeHint(self):
        return QtCore.QSize(400, 240)

    def set_state(self, state):
        self._state = state
        self.update()

    @staticmethod
    def _box(p, x, y, w, h, fill, edge=EDGE, radius=6.0):
        p.setPen(QtGui.QPen(edge, 1.5))
        p.setBrush(QtGui.QBrush(fill))
        p.drawRoundedRect(QtCore.QRectF(x, y, w, h), radius, radius)

    @staticmethod
    def _circle(p, cx, cy, r, fill, edge=EDGE):
        p.setPen(QtGui.QPen(edge, 1.5))
        p.setBrush(QtGui.QBrush(fill))
        p.drawEllipse(QtCore.QPointF(cx, cy), r, r)

    @staticmethod
    def _label(p, cx, cy, text, size=11, color=TEXT):
        p.setPen(QtGui.QPen(color))
        font = p.font()
        font.setPointSize(size)
        font.setBold(True)
        p.setFont(font)
        p.drawText(QtCore.QRectF(cx - 30, cy - 12, 60, 24), QtCore.Qt.AlignCenter, text)

    def paintEvent(self, event):
        s = self._state
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        scale = min(self.width() / self.W, self.height() / self.H)
        p.translate((self.width() - self.W * scale) / 2,
                    (self.height() - self.H * scale) / 2)
        p.scale(scale, scale)

        ax = s.axes.get
        pressed = s.buttons.get

        # triggers (fill level) and bumpers
        for x, key, name in ((60, "lt", "LT"), (270, "rt", "RT")):
            self._box(p, x, 0, 70, 12, IDLE, radius=3)
            level = ax(key, 0.0)
            if level > 0:
                self._box(p, x, 0, 70 * level, 12, AMBER, edge=AMBER, radius=3)
        for x, key, name in ((60, "lb", "LB"), (270, "rb", "RB")):
            self._box(p, x, 18, 70, 20, ACCENT if pressed(key) else IDLE, radius=4)
            self._label(p, x + 35, 28, name, 9,
                        QtGui.QColor("white") if pressed(key) else MUTED)

        # body
        self._box(p, 25, 44, 350, 170, BODY, radius=40)

        # sticks: a well with a dot that follows the stick
        for cx, cy, kx, ky, color in ((115, 105, "left_x", "left_y", ACCENT),
                                      (255, 160, "right_x", "right_y", GREEN)):
            self._circle(p, cx, cy, 38, QtGui.QColor("#f4f4f4"))
            dx, dy = ax(kx, 0.0) * 26, -ax(ky, 0.0) * 26
            self._circle(p, cx + dx, cy + dy, 13, color, edge=color)

        # face buttons
        for cx, cy, key, name, color in ((320, 125, "a", "A", GREEN),
                                         (345, 100, "b", "B", RED),
                                         (295, 100, "x", "X", ACCENT),
                                         (320, 75, "y", "Y", AMBER)):
            on = pressed(key)
            self._circle(p, cx, cy, 13, color if on else IDLE, edge=color)
            self._label(p, cx, cy, name, 10, QtGui.QColor("white") if on else MUTED)

        # back / start
        for cx, key in ((175, "back"), (225, "start")):
            self._circle(p, cx, 100, 7, TEXT if pressed(key) else IDLE)

        if not s.connected:
            p.setPen(QtGui.QPen(RED))
            font = p.font()
            font.setPointSize(14)
            font.setBold(True)
            p.setFont(font)
            p.fillRect(QtCore.QRectF(60, 100, 280, 40), QtGui.QColor(255, 255, 255, 220))
            p.drawText(QtCore.QRectF(60, 100, 280, 40), QtCore.Qt.AlignCenter,
                       "No controller found")
        p.end()
