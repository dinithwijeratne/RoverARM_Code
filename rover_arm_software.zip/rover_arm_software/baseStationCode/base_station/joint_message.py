"""Build the arrays for the ROS2 JointState command (no ROS in here).

Axis 0 is a DC motor, so it is sent as a speed: position[axis_0] = NaN and
velocity[axis_0] = speed as a fraction (-1 to 1). The other four joints are
servo angles in radians in `position`, and their `velocity` entries are NaN.

The arm controller on the Orange Pi refuses a message whose axis_0 has no speed, so an angle
can never be read as a motor speed.
"""
import math

from .joints import JOINT_ORDER

NAN = float("nan")


def joint_state_arrays(targets):
    """targets: joint name -> degrees, except axis_0 which is motor percent.
    Returns (names, position, velocity)."""
    names = list(JOINT_ORDER)
    position = [NAN] + [math.radians(targets[n]) for n in JOINT_ORDER[1:]]
    velocity = [targets["axis_0"] / 100.0] + [NAN] * (len(JOINT_ORDER) - 1)
    return names, position, velocity
