"""Main window for the arm base station (arm control only, no chassis).

Layout follows the PDR mockup: header (title, mission timer, link status, mode
buttons), controller view on the left, arm side view in the middle, pressure and
temperature on the right, status strip along the bottom. Light theme with large
text and controls because it is used outdoors.
"""
import time

import pyqtgraph as pg
from PyQt5 import QtCore, QtGui, QtWidgets

from .arm_control import ArmController
from .arm_view import compute_pose
from .widgets import ControllerView

GOOD = "#1e8e3e"
BAD = "#c5221f"
WARN = "#b8720c"
MUTED = "#6b6b6b"
ACCENT = "#1f6feb"

STYLE = """
QMainWindow, QWidget { background: #ffffff; color: #1a1a1a; font-size: 15px; }
QLabel { background: transparent; }
QFrame#panel { background: #f0f0f0; border: 1px solid #d5d5d5; border-radius: 8px; }
QPushButton { background: #ffffff; border: 1px solid #c8c8c8; border-radius: 6px; padding: 9px 14px; }
QPushButton:disabled { background: #e6e6e6; color: #9a9a9a; }
QPushButton:checked { background: #1e8e3e; color: #ffffff; border-color: #1e8e3e; font-weight: bold; }
QPushButton#modeActive { background: #1f6feb; color: #ffffff; border-color: #1f6feb; font-weight: bold; }
"""

# Arm drawing line widths, in screen pixels. Change these to make the arm
# thinner or thicker.
LINK_WIDTH_PX = 4
JAW_WIDTH_PX = 3

PRETTY_INPUTS = {
    "left_x": "Left stick \u2194", "left_y": "Left stick \u2195",
    "right_x": "Right stick \u2194", "right_y": "Right stick \u2195",
    "lt": "LT", "rt": "RT",
}


def _pixel_pen(color, width_px):
    """A pen whose width is in screen pixels. Without setCosmetic(True) the
    width is measured in the plot's own units (inches), not pixels."""
    pen = QtGui.QPen(QtGui.QColor(color))
    pen.setWidth(width_px)
    pen.setCosmetic(True)
    pen.setCapStyle(QtCore.Qt.RoundCap)
    pen.setJoinStyle(QtCore.Qt.RoundJoin)
    return pen


def _fmt_clock(seconds):
    seconds = int(seconds)
    return f"{seconds // 3600:02d}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"


def _colored(label, text, color, bold=True):
    label.setText(text)
    label.setStyleSheet(
        f"color: {color}; font-weight: {'bold' if bold else 'normal'};")


def _panel(title):
    frame = QtWidgets.QFrame()
    frame.setObjectName("panel")
    col = QtWidgets.QVBoxLayout(frame)
    col.setContentsMargins(14, 10, 14, 12)
    heading = QtWidgets.QLabel(title)
    heading.setStyleSheet(f"color: {MUTED}; font-size: 14px;")
    col.addWidget(heading)
    return frame, col


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, config, link, reader):
        super().__init__()
        self._cfg = config
        self._link = link
        self._reader = reader
        self._arm = ArmController(config.joints, config.settings.deadzone)
        self._state = reader.poll()
        self._output_on = False
        self._last_tick = time.monotonic()
        self._clock_running = False
        self._clock_started = 0.0
        self._clock_elapsed = 0.0

        pg.setConfigOption("background", "w")
        pg.setConfigOption("foreground", "k")
        pg.setConfigOptions(antialias=True)

        self.setWindowTitle("Rover arm ground station")
        self.setStyleSheet(STYLE)

        root = QtWidgets.QWidget()
        self.setCentralWidget(root)
        outer = QtWidgets.QVBoxLayout(root)
        outer.setContentsMargins(20, 14, 20, 14)
        outer.setSpacing(12)
        outer.addLayout(self._build_header())

        panels = QtWidgets.QHBoxLayout()
        panels.setSpacing(14)
        panels.addWidget(self._build_controller_panel(), 4)
        panels.addWidget(self._build_arm_panel(), 5)
        panels.addWidget(self._build_telemetry_panel(), 4)
        outer.addLayout(panels, 1)
        outer.addWidget(self._build_status_strip())

        rate = config.settings.command_rate_hz
        self._command_timer = QtCore.QTimer(self)
        self._command_timer.timeout.connect(self._command_tick)
        self._command_timer.start(max(1, int(1000 / rate)))

        self._display_timer = QtCore.QTimer(self)
        self._display_timer.timeout.connect(self._refresh)
        self._display_timer.start(50)    # 20 Hz

    def _build_header(self):
        row = QtWidgets.QHBoxLayout()

        left = QtWidgets.QVBoxLayout()
        title = QtWidgets.QLabel("Rover arm ground station")
        title.setStyleSheet("font-size: 26px; font-weight: bold;")
        sub = QtWidgets.QLabel("Arm control only")
        sub.setStyleSheet(f"color: {MUTED}; font-size: 13px; font-style: italic;")
        left.addWidget(title)
        left.addWidget(sub)
        left.addStretch(1)
        row.addLayout(left)
        row.addStretch(1)

        right = QtWidgets.QVBoxLayout()
        right.setSpacing(4)

        clock_row = QtWidgets.QHBoxLayout()
        clock_row.addStretch(1)
        caption = QtWidgets.QLabel("Mission time")
        caption.setStyleSheet(f"color: {MUTED}; font-size: 13px;")
        self._clock_label = QtWidgets.QLabel("00:00:00")
        self._clock_label.setStyleSheet("font-size: 28px; font-weight: bold;")
        self._clock_button = QtWidgets.QPushButton("Start")
        self._clock_button.clicked.connect(self._toggle_clock)
        reset = QtWidgets.QPushButton("Reset")
        reset.clicked.connect(self._reset_clock)
        clock_row.addWidget(caption)
        clock_row.addWidget(self._clock_label)
        clock_row.addWidget(self._clock_button)
        clock_row.addWidget(reset)
        right.addLayout(clock_row)

        self._link_label = QtWidgets.QLabel()
        self._link_label.setAlignment(QtCore.Qt.AlignRight)
        right.addWidget(self._link_label)

        mode_row = QtWidgets.QHBoxLayout()
        mode_row.addStretch(1)
        mac = QtWidgets.QPushButton("MAC")
        mac.setObjectName("modeActive")
        mac.setMinimumWidth(130)
        mac.setToolTip("Manual Angle Control: sticks move the joints directly")
        ik = QtWidgets.QPushButton("IK")
        ik.setMinimumWidth(130)
        ik.setEnabled(False)
        ik.setToolTip("Inverse kinematics is not built yet")
        mode_row.addWidget(mac)
        mode_row.addWidget(ik)
        right.addLayout(mode_row)
        row.addLayout(right)
        return row

    def _build_controller_panel(self):
        frame, col = _panel("Controller input")
        self._controller_view = ControllerView()
        col.addWidget(self._controller_view, 1)

        self._raw_label = QtWidgets.QLabel()
        self._raw_label.setWordWrap(True)
        self._raw_label.setStyleSheet(f"color: {MUTED}; font-size: 12px;")
        col.addWidget(self._raw_label)

        legend_lines = []
        for j in self._cfg.joints:
            sources = []
            if j.axis is not None:
                sources.append(PRETTY_INPUTS.get(j.axis, j.axis) +
                               (" (inverted)" if j.scale < 0 else ""))
            if j.button_plus is not None:
                sources.append(f"{j.button_plus.upper()} +")
            if j.button_minus is not None:
                sources.append(f"{j.button_minus.upper()} \u2212")
            note = " (motor speed)" if j.drive == "motor" else ""
            legend_lines.append(f"{' / '.join(sources)}  \u2192  {j.name}{note}")
        legend = QtWidgets.QLabel("\n".join(legend_lines))
        legend.setStyleSheet("font-size: 13px;")
        col.addWidget(legend)

        buttons = QtWidgets.QHBoxLayout()
        self._output_button = QtWidgets.QPushButton("Arm output: OFF")
        self._output_button.setCheckable(True)
        self._output_button.setMinimumHeight(48)
        self._output_button.toggled.connect(self._on_output_toggled)
        home = QtWidgets.QPushButton("Reset to home")
        home.setMinimumHeight(48)
        home.clicked.connect(self._arm.reset_home)
        buttons.addWidget(self._output_button, 3)
        buttons.addWidget(home, 2)
        col.addLayout(buttons)

        hint = QtWidgets.QLabel(
            "Nothing is sent until output is ON. The servos have no position "
            "feedback, so start with the arm at its home pose.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {MUTED}; font-size: 12px;")
        col.addWidget(hint)
        return frame

    def _build_arm_panel(self):
        frame, col = _panel("Arm position (commanded angles, side view)")
        v = self._cfg.view
        reach = v.shoulder.length + v.elbow.length + v.wrist.length

        plot = pg.PlotWidget(background="w")
        plot.setAspectLocked(True)
        plot.setMenuEnabled(False)
        plot.setMouseEnabled(x=False, y=False)
        plot.hideButtons()
        plot.showGrid(x=True, y=True, alpha=0.2)
        plot.setLabel("bottom", f"forward ({v.units})")
        plot.setLabel("left", f"up ({v.units})")
        plot.setXRange(-reach * 0.3, reach * 1.1, padding=0)
        plot.setYRange(-v.base_height - 2, reach * 1.1, padding=0)

        ground = -v.base_height
        plot.plot([-reach * 0.3, reach * 1.1], [ground, ground],
                  pen=pg.mkPen("#999999", width=2))
        plot.plot([-3, 3, 3, -3, -3], [ground, ground, 0, 0, ground],
                  pen=pg.mkPen("#666666", width=3))

        link_pen = _pixel_pen("#1a1a1a", LINK_WIDTH_PX)
        jaw_pen = _pixel_pen(WARN, JAW_WIDTH_PX)

        self._links_curve = plot.plot([], [], pen=link_pen)
        self._jaw_curves = [plot.plot([], [], pen=jaw_pen) for _ in range(2)]
        self._joint_dots = pg.ScatterPlotItem(
            size=10, brush=pg.mkBrush(ACCENT), pen=pg.mkPen("w", width=1.5))
        plot.addItem(self._joint_dots)
        col.addWidget(plot, 1)

        grid = QtWidgets.QGridLayout()
        self._angle_labels = {}
        for i, j in enumerate(self._cfg.joints):
            name = QtWidgets.QLabel(j.name)
            name.setAlignment(QtCore.Qt.AlignCenter)
            name.setStyleSheet(f"color: {MUTED}; font-size: 12px;")
            value = QtWidgets.QLabel("--")
            value.setAlignment(QtCore.Qt.AlignCenter)
            value.setStyleSheet("font-weight: bold;")
            grid.addWidget(name, 0, i)
            grid.addWidget(value, 1, i)
            self._angle_labels[j.name] = value
        col.addLayout(grid)
        return frame

    def _build_telemetry_panel(self):
        frame, col = _panel("Sensor telemetry")
        h = self._cfg.settings.history_s
        self._plots = {}
        for key, title, units, color in (
                ("pressure", "Pressure", "kPa", GOOD),
                ("temperature", "Temperature", "\u00b0C", WARN)):
            value = QtWidgets.QLabel(f"{title}: --")
            value.setStyleSheet("font-weight: bold;")
            col.addWidget(value)
            plot = pg.PlotWidget(background="w")
            plot.setMenuEnabled(False)
            plot.setMouseEnabled(x=False, y=False)
            plot.hideButtons()
            plot.showGrid(x=True, y=True, alpha=0.3)
            plot.setLabel("left", units)
            plot.setLabel("bottom", "seconds ago")
            plot.setXRange(-h, 0, padding=0)
            curve = plot.plot(pen=pg.mkPen(color, width=2))
            col.addWidget(plot, 1)
            self._plots[key] = (title, units, value, curve)
        return frame

    def _build_status_strip(self):
        frame = QtWidgets.QFrame()
        frame.setObjectName("panel")
        row = QtWidgets.QHBoxLayout(frame)
        row.setContentsMargins(14, 10, 14, 10)
        self._status = {}
        for key in ("controller", "pressure", "temperature", "output"):
            label = QtWidgets.QLabel()
            self._status[key] = label
            row.addWidget(label, 1)
        return frame

    def _stop_motors(self):
        """A DC motor keeps spinning if commands stop, so send an explicit stop."""
        if any(j.drive == "motor" for j in self._cfg.joints):
            self._arm.stop_motors()
            self._link.send_command(self._arm.targets, force=True)

    def _on_output_toggled(self, checked):
        if not checked and self._output_on:
            self._stop_motors()
        self._output_on = checked
        self._last_tick = time.monotonic()
        self._output_button.setText("Arm output: ON" if checked else "Arm output: OFF")

    def _toggle_clock(self):
        if self._clock_running:
            self._clock_elapsed += time.monotonic() - self._clock_started
            self._clock_running = False
            self._clock_button.setText("Start")
        else:
            self._clock_started = time.monotonic()
            self._clock_running = True
            self._clock_button.setText("Pause")

    def _reset_clock(self):
        self._clock_running = False
        self._clock_elapsed = 0.0
        self._clock_button.setText("Start")

    def _command_tick(self):
        """Read the controller, update targets, and send them (only if ON)."""
        now = time.monotonic()
        dt = now - self._last_tick
        self._last_tick = now
        self._state = self._reader.poll()
        if self._output_on:
            targets = self._arm.update(self._state, dt)
            self._link.send_command(targets)

    def _refresh(self):
        snap = self._link.snapshot()
        state = self._state
        stale = self._cfg.settings.stale_after_s

        self._controller_view.set_state(state)
        if state.connected:
            axes = " ".join(f"{a:+.2f}" for a in state.raw_axes)
            pressed = [i for i, b in enumerate(state.raw_buttons) if b]
            self._raw_label.setText(f"raw axes: {axes}\nraw buttons pressed: {pressed or 'none'}")
        else:
            self._raw_label.setText("Plug in an Xbox controller.")

        targets = dict(self._arm.targets)
        pose = compute_pose(targets, self._cfg.joints, self._cfg.view)
        pts = [pose.shoulder, pose.elbow, pose.wrist, pose.tip]
        self._links_curve.setData([p[0] for p in pts], [p[1] for p in pts])
        self._joint_dots.setData(x=[p[0] for p in pts[:3]], y=[p[1] for p in pts[:3]])
        for curve, jaw in zip(self._jaw_curves, (pose.jaw_a, pose.jaw_b)):
            curve.setData([pose.tip[0], jaw[0]], [pose.tip[1], jaw[1]])
        for j in self._cfg.joints:
            value = targets[j.name]
            self._angle_labels[j.name].setText(
                f"{value:+.0f}%" if j.drive == "motor" else f"{value:.1f}\u00b0")

        for key, series, age in (("pressure", snap.pressure, snap.pressure_age_s),
                                 ("temperature", snap.temperature, snap.temperature_age_s)):
            title, units, value_label, curve = self._plots[key]
            xs, ys = series
            curve.setData(xs, ys[0], connect="finite")
            latest = f"{ys[0][-1]:.2f} {units}" if ys[0] else "--"
            value_label.setText(f"{title}: {latest}")
            if age is None:
                _colored(self._status[key], f"{title}: NO DATA", BAD)
            elif age > stale:
                _colored(self._status[key], f"{title}: STALE ({age:.0f} s)", BAD)
            else:
                _colored(self._status[key], f"{title}: OK", GOOD)

        if state.connected:
            _colored(self._status["controller"], f"Controller: {state.name or 'OK'}", GOOD)
        else:
            _colored(self._status["controller"], "Controller: NOT FOUND", BAD)
        _colored(self._status["output"],
                 "Arm output: ON" if self._output_on else "Arm output: OFF",
                 GOOD if self._output_on else MUTED)

        if snap.kind == "sim":
            _colored(self._link_label, f"Link: {snap.link_text}", WARN)
        else:
            _colored(self._link_label, f"Link: {snap.link_text}",
                     GOOD if snap.link_ok else BAD)

        elapsed = self._clock_elapsed
        if self._clock_running:
            elapsed += time.monotonic() - self._clock_started
        self._clock_label.setText(_fmt_clock(elapsed))

    def closeEvent(self, event):
        if self._output_on:
            self._stop_motors()
        self._output_on = False
        self._command_timer.stop()
        self._display_timer.stop()
        event.accept()
