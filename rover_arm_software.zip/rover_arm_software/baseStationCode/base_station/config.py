"""Load and validate config/arm.yaml (no Qt, no ROS, no pygame)."""
import sys
from dataclasses import dataclass

import yaml

from .arm_control import JointConfig
from .joints import JOINT_ORDER

AXIS_NAMES = ("left_x", "left_y", "right_x", "right_y", "lt", "rt")
BUTTON_NAMES = ("a", "b", "x", "y", "lb", "rb", "back", "start")


@dataclass(frozen=True)
class ControllerProfile:
    axes: dict       # logical axis name -> raw pygame axis index
    buttons: dict    # logical button name -> raw pygame button index


@dataclass(frozen=True)
class ViewJoint:
    """How a servo angle is drawn. Drawn angle = home_display_deg +
    direction * (servo angle - servo home angle). The shoulder angle is measured
    from horizontal; elbow and wrist angles are relative to the previous link."""
    home_display_deg: float
    direction: float
    length: float


@dataclass(frozen=True)
class ArmViewConfig:
    units: str
    base_height: float
    shoulder: ViewJoint
    elbow: ViewJoint
    wrist: ViewJoint
    jaw_len: float
    jaw_max_open_deg: float


@dataclass(frozen=True)
class Settings:
    deadzone: float = 0.12
    command_rate_hz: float = 50.0
    history_s: float = 60.0
    stale_after_s: float = 2.0
    command_topic: str = "arm/joint_command"
    pressure_topic: str = "arm/pressure"
    temperature_topic: str = "arm/temperature"
    serial_send_hz: float = 20.0         # most M lines per second sent to the Pico
    serial_heartbeat_s: float = 0.5      # repeat an unchanged command this often


@dataclass(frozen=True)
class AppConfig:
    joints: tuple
    settings: Settings
    profiles: dict
    view: ArmViewConfig

    def profile_for(self, platform=None):
        platform = platform or sys.platform
        key = "windows" if platform.startswith("win") else "linux"
        if key in self.profiles:
            return self.profiles[key]
        return next(iter(self.profiles.values()))


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return parse_config(data)


def _number(value, what, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{what} must be a number, got {value!r}")
    if positive and value <= 0:
        raise ValueError(f"{what} must be > 0")
    return float(value)


def _index_map(raw, allowed, what, required=()):
    if not isinstance(raw, dict):
        raise ValueError(f"{what} must be a mapping")
    out = {}
    for name, index in raw.items():
        if name not in allowed:
            raise ValueError(f"{what}: unknown name '{name}'")
        if isinstance(index, bool) or not isinstance(index, int) or index < 0:
            raise ValueError(f"{what}.{name} must be a non-negative integer")
        out[name] = index
    for name in required:
        if name not in out:
            raise ValueError(f"{what} is missing '{name}'")
    return out


def _parse_profiles(raw):
    if not isinstance(raw, dict) or not raw:
        raise ValueError("controller.profiles needs at least one profile")
    profiles = {}
    for key, body in raw.items():
        axes = _index_map((body or {}).get("axes"), AXIS_NAMES,
                          f"profile '{key}' axes",
                          required=("left_x", "left_y", "right_x", "right_y"))
        buttons = _index_map((body or {}).get("buttons"), BUTTON_NAMES,
                             f"profile '{key}' buttons")
        profiles[key] = ControllerProfile(axes=axes, buttons=buttons)
    return profiles


def _parse_joints(raw_joints):
    if not isinstance(raw_joints, list) or not raw_joints:
        raise ValueError("config needs a non-empty 'joints' list")

    joints = {}
    for raw in raw_joints:
        name = raw.get("name")
        if name not in JOINT_ORDER:
            raise ValueError(f"unknown joint '{name}'; expected {list(JOINT_ORDER)}")
        if name in joints:
            raise ValueError(f"duplicate joint name '{name}'")
        if "input" not in raw:
            raise ValueError(f"joint '{name}' is missing 'input'")

        # Axis 0 is a DC motor on this arm; the other four joints are servos.
        drive = raw.get("drive", "motor" if name == "axis_0" else "servo")
        if name == "axis_0" and drive != "motor":
            raise ValueError("joint 'axis_0' is a DC motor on this arm: "
                             "use drive: motor (or leave 'drive' out)")
        if name != "axis_0" and drive != "servo":
            raise ValueError(f"joint '{name}' is a servo: only axis_0 is a motor")

        if drive == "motor":
            speed = _number(raw.get("max_speed_pct"), f"{name}.max_speed_pct", positive=True)
            if speed > 100:
                raise ValueError(f"joint '{name}': max_speed_pct can't exceed 100")
            lo, hi, home, rate = -speed, speed, 0.0, 1.0     # degree fields unused
        else:
            speed = 0.0
            for key in ("min_deg", "max_deg", "home_deg", "max_rate_dps"):
                if key not in raw:
                    raise ValueError(f"joint '{name}' is missing '{key}'")
            lo = _number(raw["min_deg"], f"{name}.min_deg")
            hi = _number(raw["max_deg"], f"{name}.max_deg")
            home = _number(raw["home_deg"], f"{name}.home_deg")
            rate = _number(raw["max_rate_dps"], f"{name}.max_rate_dps", positive=True)
            if not lo < hi:
                raise ValueError(f"joint '{name}': min_deg must be < max_deg")
            if not lo <= home <= hi:
                raise ValueError(f"joint '{name}': home_deg must be within limits")

        inp = raw["input"] or {}
        axis = inp.get("axis")
        plus = inp.get("button_plus")
        minus = inp.get("button_minus")
        if axis is not None and axis not in AXIS_NAMES:
            raise ValueError(f"joint '{name}': unknown axis '{axis}'")
        for b in (plus, minus):
            if b is not None and b not in BUTTON_NAMES:
                raise ValueError(f"joint '{name}': unknown button '{b}'")
        if axis is None and plus is None and minus is None:
            raise ValueError(f"joint '{name}' has no controller input mapped")

        joints[name] = JointConfig(
            name=name, min_deg=lo, max_deg=hi, home_deg=home, max_rate_dps=rate,
            axis=axis, scale=_number(inp.get("scale", 1.0), f"{name}.input.scale"),
            button_plus=plus, button_minus=minus, drive=drive, max_speed_pct=speed)

    missing = [n for n in JOINT_ORDER if n not in joints]
    if missing:
        raise ValueError(f"config is missing joints: {missing}")
    return tuple(joints[n] for n in JOINT_ORDER)


def _parse_view_joint(raw, what):
    if not isinstance(raw, dict):
        raise ValueError(f"arm_view.{what} must be a mapping")
    direction = _number(raw.get("direction"), f"arm_view.{what}.direction")
    if direction not in (-1.0, 1.0):
        raise ValueError(f"arm_view.{what}.direction must be 1 or -1")
    return ViewJoint(
        home_display_deg=_number(raw.get("home_display_deg"),
                                 f"arm_view.{what}.home_display_deg"),
        direction=direction,
        length=_number(raw.get("length"), f"arm_view.{what}.length", positive=True))


def _parse_view(raw):
    if not isinstance(raw, dict):
        raise ValueError("config needs an 'arm_view' section")
    return ArmViewConfig(
        units=str(raw.get("units", "in")),
        base_height=_number(raw.get("base_height"), "arm_view.base_height", positive=True),
        shoulder=_parse_view_joint(raw.get("shoulder"), "shoulder"),
        elbow=_parse_view_joint(raw.get("elbow"), "elbow"),
        wrist=_parse_view_joint(raw.get("wrist"), "wrist"),
        jaw_len=_number(raw.get("jaw_len"), "arm_view.jaw_len", positive=True),
        jaw_max_open_deg=_number(raw.get("jaw_max_open_deg"),
                                 "arm_view.jaw_max_open_deg", positive=True))


def parse_config(data):
    ctrl = data.get("controller") or {}
    tel = data.get("telemetry") or {}
    ros = data.get("ros") or {}
    ser = data.get("serial") or {}
    d = Settings()

    settings = Settings(
        deadzone=_number(ctrl.get("deadzone", d.deadzone), "controller.deadzone"),
        command_rate_hz=_number(ctrl.get("command_rate_hz", d.command_rate_hz),
                                "controller.command_rate_hz", positive=True),
        history_s=_number(tel.get("history_s", d.history_s),
                          "telemetry.history_s", positive=True),
        stale_after_s=_number(tel.get("stale_after_s", d.stale_after_s),
                              "telemetry.stale_after_s", positive=True),
        command_topic=str(ros.get("command_topic", d.command_topic)),
        pressure_topic=str(ros.get("pressure_topic", d.pressure_topic)),
        temperature_topic=str(ros.get("temperature_topic", d.temperature_topic)),
        serial_send_hz=_number(ser.get("send_rate_hz", d.serial_send_hz),
                               "serial.send_rate_hz", positive=True),
        serial_heartbeat_s=_number(ser.get("heartbeat_s", d.serial_heartbeat_s),
                                   "serial.heartbeat_s", positive=True),
    )
    if not 0.0 <= settings.deadzone < 1.0:
        raise ValueError("controller.deadzone must be in [0, 1)")

    return AppConfig(
        joints=_parse_joints(data.get("joints")),
        settings=settings,
        profiles=_parse_profiles(ctrl.get("profiles")),
        view=_parse_view(data.get("arm_view")))
