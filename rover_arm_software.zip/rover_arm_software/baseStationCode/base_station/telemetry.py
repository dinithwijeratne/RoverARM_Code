"""Rolling time-window storage for plotted telemetry (no Qt, no ROS)."""
from collections import deque


class SeriesHistory:
    """Keeps the last `window_s` seconds of a multi-channel signal."""

    def __init__(self, n_channels, window_s):
        self.n_channels = n_channels
        self.window_s = window_s
        self.last_time = None
        self._times = deque()
        self._values = deque()

    def add(self, t, values):
        if len(values) != self.n_channels:
            raise ValueError(
                f"expected {self.n_channels} values, got {len(values)}")
        self._times.append(t)
        self._values.append(tuple(values))
        self.last_time = t
        self._prune(t)

    def age(self, now):
        """Seconds since the last sample, or None if nothing has arrived."""
        return None if self.last_time is None else now - self.last_time

    def _prune(self, now):
        cutoff = now - self.window_s
        while self._times and self._times[0] < cutoff:
            self._times.popleft()
            self._values.popleft()

    def snapshot(self, now):
        """Return (xs, ys): xs are seconds relative to `now` (<= 0),
        ys is one list per channel."""
        self._prune(now)
        xs = [t - now for t in self._times]
        ys = [[v[c] for v in self._values] for c in range(self.n_channels)]
        return xs, ys
