"""Serial link to the Pico. No ROS dependency, so it can be tested anywhere.

The bridge reconnects on its own, sends M command lines, and turns the Pico's
printed Temperature and Pressure lines into callbacks.

  * Commands are rate limited and an unchanged command is only repeated as a
    heartbeat, so the Pico's receive buffer is not overrun.
  * send_stop() sends a motor stop with the last servo angles, because the
    Pico updates every servo on every line.
"""
import threading
import time

from . import pico_protocol as protocol

EVENT_THROTTLE_S = 5.0     # the same message is shown at most this often


def _open_pyserial(port, baud):
    try:
        import serial
    except ImportError:
        raise OSError("pyserial is not installed (Windows: pip install pyserial, "
                      "Linux: sudo apt install python3-serial)") from None
    return serial.Serial(port, baud, timeout=0.2)


class SerialBridge:
    """serial_factory(port, baud) must return an object with readline() (bytes,
    empty on timeout), write(bytes) and close(). It defaults to pyserial."""

    def __init__(self, port, baud=115200, on_telemetry=None, on_event=None,
                 serial_factory=None, retry_s=2.0, on_line=None,
                 send_rate_hz=20.0, heartbeat_s=0.5, clock=time.monotonic):
        self._port = port
        self._baud = baud
        self._on_telemetry = on_telemetry or (lambda tel: None)
        self._on_event = on_event or (lambda level, text: None)
        self._on_line = on_line          # called with every non-empty line, raw
        self._factory = serial_factory or _open_pyserial
        self._retry_s = retry_s
        self._clock = clock
        self._min_interval_s = 1.0 / send_rate_hz
        self._heartbeat_s = heartbeat_s

        self._serial = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self._last_event = {}
        self._parser = protocol.TelemetryParser()

        self._last_line = None           # last M line actually written
        self._last_write = float("-inf")
        self._last_servos = None         # servo angles of the last command
        self.commands_sent = 0
        self.telemetry_ok = 0

    @property
    def connected(self):
        return self._serial is not None

    @property
    def telemetry_bad(self):
        return self._parser.bad

    def start(self):
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.5)
        self._close()

    def _event(self, level, text, key=None):
        key = key or text
        now = time.monotonic()
        if now - self._last_event.get(key, -EVENT_THROTTLE_S) >= EVENT_THROTTLE_S:
            self._last_event[key] = now
            self._on_event(level, text)

    def _close(self):
        with self._lock:
            ser, self._serial = self._serial, None
        if ser is not None:
            try:
                ser.close()
            except Exception:
                pass

    def send_command(self, speed_pct, servo_angles_deg, force=False):
        """Send the motor speed (percent) and the four servo angles (degrees).

        Returns True if the command was accepted (written now, or deliberately
        skipped because the Pico already has it or is being sent too fast).
        Returns False if it was refused or could not be written. `force=True`
        skips the rate limit; use it for stops."""
        try:
            line = protocol.encode_command(speed_pct, servo_angles_deg)
        except protocol.ProtocolError as exc:
            self._event("warn", f"Not sending a bad command: {exc}", "bad_cmd")
            return False
        now = self._clock()
        with self._lock:
            ser = self._serial
            if ser is None:
                self._event("warn", f"Pico not connected on {self._port}; "
                                    "dropping command", "no_serial")
                return False
            since = now - self._last_write
            if not force:
                if line == self._last_line and since < self._heartbeat_s:
                    return True          # Pico already has this one
                if since < self._min_interval_s:
                    return True          # too soon; the next tick carries it
            try:
                ser.write(line.encode("ascii"))
            except OSError as exc:
                self._event("warn", f"Serial write failed: {exc!r}", "write")
                self._serial = None
                try:
                    ser.close()
                except Exception:
                    pass
                return False
            self._last_line = line
            self._last_write = now
            self._last_servos = tuple(servo_angles_deg)
            self.commands_sent += 1
        return True

    def send_stop(self):
        """Stop the axis 0 motor now, leaving the servos where they were.
        Returns False if no command was ever sent (then the Pico has nothing
        running, and we have no servo angles to repeat) or the write failed."""
        servos = self._last_servos
        if servos is None:
            return False
        return self.send_command(0.0, servos, force=True)

    def _loop(self):
        while not self._stop.is_set():
            ser = self._serial
            if ser is None:
                try:
                    ser = self._factory(self._port, self._baud)
                except Exception as exc:       # includes pyserial not installed
                    self._event("warn", f"Can't open {self._port}: {exc!r}. Retrying.",
                                "open")
                    self._stop.wait(self._retry_s)
                    continue
                with self._lock:
                    self._serial = ser
                self._event("info", f"Connected to Pico on {self._port}", "connected")

            try:
                raw = ser.readline()
            except OSError as exc:
                self._event("warn", f"Serial read failed: {exc!r}", "read")
                self._close()
                continue
            if raw:
                self._handle_line(raw.decode("ascii", errors="ignore"))

    def _handle_line(self, text):
        text = text.strip()
        if not text:
            return
        if self._on_line is not None:
            try:
                self._on_line(text)
            except Exception:
                pass
        before = self._parser.bad
        tel = self._parser.feed(text)
        if self._parser.bad != before:
            self._event("warn", f"Bad sensor line from Pico: {text[:60]!r}", "bad_tel")
        if tel is None:
            return
        self.telemetry_ok += 1
        try:
            self._on_telemetry(tel)
        except Exception as exc:
            self._event("warn", f"Telemetry callback failed: {exc!r}", "callback")
