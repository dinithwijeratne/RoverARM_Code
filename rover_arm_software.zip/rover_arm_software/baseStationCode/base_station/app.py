"""Entry point: python -m base_station [--link sim|serial|ros2] [--test-controller]"""
import argparse
import sys
import time
from pathlib import Path

from .config import load_config

DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / "config" / "arm.yaml"


def _test_controller(profile, seconds=20):
    """Console check: print what the controller is sending. No window."""
    from .controller import GamepadReader

    reader = GamepadReader(profile)
    print(f"Move the sticks and press buttons. Running for {seconds} seconds "
          "(Ctrl+C to stop).\n")
    end = time.monotonic() + seconds
    last = None
    try:
        while time.monotonic() < end:
            s = reader.poll()
            if not s.connected:
                line = "No controller found. Plug in an Xbox controller."
            else:
                axes = " ".join(f"{k}={v:+.2f}" for k, v in s.axes.items())
                pressed = [k for k, v in s.buttons.items() if v] or "none"
                line = (f"{s.name} | raw axes {list(s.raw_axes)} | {axes} "
                        f"| pressed: {pressed}")
            if line != last:
                print(line)
                last = line
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        reader.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Rover arm base station")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="path to arm.yaml")
    parser.add_argument("--link", choices=("sim", "ros2", "serial"), default="sim",
                        help="sim = fake sensor data, no hardware (default); "
                             "serial = straight to the Pico over USB, any OS (needs --port); "
                             "ros2 = real link to the Orange Pi (Linux)")
    parser.add_argument("--port", help="serial port for --link serial, e.g. COM5 or /dev/ttyACM0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--test-controller", action="store_true",
                        help="print controller readings in the console and exit")
    args = parser.parse_args(argv)

    config = load_config(args.config)
    profile = config.profile_for()

    if args.test_controller:
        _test_controller(profile)
        return 0

    from PyQt5 import QtWidgets

    from .controller import GamepadReader
    from .gui import MainWindow
    from .links import make_link

    try:
        link = make_link(args.link, config.settings, args.port, args.baud)
    except ValueError as exc:
        print(exc)
        return 1
    except ImportError as exc:
        print(f"Can't start the ROS2 link ({exc}).\n"
              "On Linux, run:  source /opt/ros/jazzy/setup.bash  first.")
        return 1

    reader = GamepadReader(profile)
    app = QtWidgets.QApplication(sys.argv[:1])
    window = MainWindow(config, link, reader)
    window.resize(1400, 820)
    window.show()
    code = app.exec_()

    link.close()
    reader.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
