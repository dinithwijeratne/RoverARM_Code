"""The five arm joints, in the fixed order used everywhere (ROS2 and serial)."""

JOINT_ORDER = ("axis_0", "shoulder", "elbow", "wrist", "end_effector")
