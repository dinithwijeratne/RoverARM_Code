"""Real ROS2 link (Linux, ROS2 Jazzy sourced). Imported only for --link ros2.

Publishes joint commands, and subscribes to the pressure and temperature that
the arm controller on the Orange Pi publishes. The base station only displays telemetry; it
never acts on it.
"""
import threading
import time

import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import FluidPressure, JointState, Temperature

from .joint_message import joint_state_arrays
from .links import BaseLink, LinkSnapshot
from .telemetry import SeriesHistory


class RosLink(BaseLink):
    kind = "ros2"

    def __init__(self, settings):
        rclpy.init()
        self._node = rclpy.create_node("arm_base_station")
        self._lock = threading.Lock()
        self._pressure = SeriesHistory(1, settings.history_s)
        self._temperature = SeriesHistory(1, settings.history_s)

        self._command_pub = self._node.create_publisher(
            JointState, settings.command_topic, 10)
        self._node.create_subscription(
            FluidPressure, settings.pressure_topic, self._on_pressure,
            qos_profile_sensor_data)
        self._node.create_subscription(
            Temperature, settings.temperature_topic, self._on_temperature,
            qos_profile_sensor_data)

        self._executor = SingleThreadedExecutor()
        self._executor.add_node(self._node)
        self._thread = threading.Thread(target=self._executor.spin, daemon=True)
        self._thread.start()

    def _on_pressure(self, msg):
        with self._lock:
            self._pressure.add(time.monotonic(), (msg.fluid_pressure / 1000.0,))  # Pa -> kPa

    def _on_temperature(self, msg):
        with self._lock:
            self._temperature.add(time.monotonic(), (msg.temperature,))

    def send_command(self, targets_deg, force=False):
        msg = JointState()
        msg.header.stamp = self._node.get_clock().now().to_msg()
        msg.name, msg.position, msg.velocity = joint_state_arrays(
            targets_deg)
        self._command_pub.publish(msg)

    def snapshot(self):
        now = time.monotonic()
        relay_up = self._command_pub.get_subscription_count() > 0
        with self._lock:
            return LinkSnapshot(
                kind="ros2", link_ok=relay_up,
                link_text=("ROS2: Orange Pi connected" if relay_up
                           else "ROS2: waiting for Orange Pi"),
                pressure=self._pressure.snapshot(now),
                temperature=self._temperature.snapshot(now),
                pressure_age_s=self._pressure.age(now),
                temperature_age_s=self._temperature.age(now))

    def close(self):
        self._executor.shutdown()
        self._thread.join(timeout=2.0)
        self._node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
