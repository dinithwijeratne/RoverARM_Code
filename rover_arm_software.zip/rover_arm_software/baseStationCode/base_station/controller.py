"""Gamepad input.

`map_raw` turns raw pygame axis/button numbers into logical names (left_x,
rb, ...) using a per-OS profile, so the rest of the app never sees raw numbers.
`GamepadReader` reads the first connected controller through pygame.

Logical axes: left_x / right_x are +1 to the right, left_y / right_y are +1 UP,
lt / rt run 0 (released) to 1 (fully pressed).
"""
import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class ControllerState:
    connected: bool = False
    name: str = ""
    axes: dict = field(default_factory=dict)       # logical name -> float
    buttons: dict = field(default_factory=dict)    # logical name -> bool
    raw_axes: tuple = ()
    raw_buttons: tuple = ()


NO_CONTROLLER = ControllerState()


def _clamp(value, lo=-1.0, hi=1.0):
    return max(lo, min(hi, value))


def map_raw(raw_axes, raw_buttons, profile, name=""):
    """Convert raw numbers to a ControllerState using `profile`
    (a ControllerProfile with .axes and .buttons dicts of name -> index)."""

    def axis(logical):
        index = profile.axes.get(logical)
        if index is None or not 0 <= index < len(raw_axes):
            return None
        return float(raw_axes[index])

    def stick(logical, flip=False):
        value = axis(logical)
        if value is None:
            return 0.0
        return _clamp(-value if flip else value)

    def trigger(logical):
        value = axis(logical)
        if value is None:
            return 0.0
        return _clamp((value + 1.0) / 2.0, 0.0, 1.0)   # rest is -1, pressed is +1

    axes = {
        "left_x": stick("left_x"),
        "left_y": stick("left_y", flip=True),      # pygame reports up as negative
        "right_x": stick("right_x"),
        "right_y": stick("right_y", flip=True),
        "lt": trigger("lt"),
        "rt": trigger("rt"),
    }
    buttons = {}
    for logical, index in profile.buttons.items():
        buttons[logical] = bool(0 <= index < len(raw_buttons) and raw_buttons[index])

    return ControllerState(
        connected=True, name=name, axes=axes, buttons=buttons,
        raw_axes=tuple(round(float(a), 2) for a in raw_axes),
        raw_buttons=tuple(int(bool(b)) for b in raw_buttons))


class GamepadReader:
    """Reads the first connected controller with pygame (no window is opened)."""

    def __init__(self, profile):
        # Must be set before pygame starts.
        os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
        os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        import pygame

        self._pg = pygame
        self._profile = profile
        self._joystick = None
        pygame.display.init()      # needed for the event system; the driver is "dummy"
        pygame.joystick.init()
        if pygame.joystick.get_count() > 0:
            self._joystick = pygame.joystick.Joystick(0)

    def poll(self):
        pg = self._pg
        for event in pg.event.get():
            if event.type == pg.JOYDEVICEADDED and self._joystick is None:
                self._joystick = pg.joystick.Joystick(event.device_index)
            elif event.type == pg.JOYDEVICEREMOVED:
                if (self._joystick is not None and
                        event.instance_id == self._joystick.get_instance_id()):
                    self._joystick = None

        js = self._joystick
        if js is None:
            return NO_CONTROLLER
        try:
            raw_axes = [js.get_axis(i) for i in range(js.get_numaxes())]
            raw_buttons = [js.get_button(i) for i in range(js.get_numbuttons())]
            name = js.get_name()
        except pg.error:
            self._joystick = None
            return NO_CONTROLLER
        return map_raw(raw_axes, raw_buttons, self._profile, name)

    def close(self):
        self._pg.joystick.quit()
        self._pg.display.quit()
