"""Manual Angle Control (MAC): controller input -> joint target angles.

Pure Python (no Qt, no ROS, no pygame) so it can be unit tested anywhere.

Stick deflection sets how fast a joint moves, not where it goes. Each update,
the target angle moves by (stick * max_rate * dt) and is clamped to the joint's
limits. Let go of the stick and the target holds where it is.

A joint driven by a DC motor (only axis 0 can be) is different: there is no
angle to hold, so the stick sets the motor SPEED directly, as a percent from
-max_speed_pct to +max_speed_pct. Let go and the speed is zero.
"""
from dataclasses import dataclass
from typing import Optional, Sequence

# Longest time step integrated in one update, so a stall can't cause a jump.
MAX_DT_S = 0.1


@dataclass(frozen=True)
class JointConfig:
    name: str
    min_deg: float
    max_deg: float
    home_deg: float
    max_rate_dps: float
    axis: Optional[str] = None            # logical axis name, e.g. "left_x"
    scale: float = 1.0                    # use -1.0 to flip an axis
    button_plus: Optional[str] = None     # logical button held -> angle increases
    button_minus: Optional[str] = None    # logical button held -> angle decreases
    drive: str = "servo"                  # "servo" (an angle) or "motor" (a speed)
    max_speed_pct: float = 0.0            # motor only: speed limit, percent


def apply_deadzone(value: float, deadzone: float) -> float:
    """Zero inside the deadzone, then ramp smoothly from 0 to +/-1."""
    magnitude = abs(value)
    if magnitude <= deadzone:
        return 0.0
    ramped = (magnitude - deadzone) / (1.0 - deadzone)
    return ramped if value > 0 else -ramped


class ArmController:
    def __init__(self, joints: Sequence[JointConfig], deadzone: float = 0.12):
        self.joints = tuple(joints)
        self.deadzone = deadzone
        self.targets = {j.name: j.home_deg for j in self.joints}

    def reset_home(self) -> None:
        self.targets = {j.name: j.home_deg for j in self.joints}   # motors: 0 percent

    def stop_motors(self) -> None:
        """Set every motor joint to zero speed. Servo targets are left alone."""
        for j in self.joints:
            if j.drive == "motor":
                self.targets[j.name] = 0.0

    def command_for(self, joint: JointConfig, state) -> float:
        """Normalized command in [-1, 1] for one joint. `state` is a
        ControllerState; a disconnected controller has empty dicts, so every
        command is zero and the arm holds still."""
        cmd = 0.0
        if joint.axis is not None:
            cmd += apply_deadzone(state.axes.get(joint.axis, 0.0),
                                  self.deadzone) * joint.scale
        if joint.button_plus is not None and state.buttons.get(joint.button_plus):
            cmd += 1.0
        if joint.button_minus is not None and state.buttons.get(joint.button_minus):
            cmd -= 1.0
        return max(-1.0, min(1.0, cmd))

    def update(self, state, dt: float) -> dict:
        """Advance all targets by one time step and return a copy of them."""
        dt = max(0.0, min(dt, MAX_DT_S))
        for joint in self.joints:
            cmd = self.command_for(joint, state)
            if joint.drive == "motor":
                self.targets[joint.name] = cmd * joint.max_speed_pct
                continue
            moved = self.targets[joint.name] + cmd * joint.max_rate_dps * dt
            self.targets[joint.name] = min(joint.max_deg,
                                           max(joint.min_deg, moved))
        return dict(self.targets)
