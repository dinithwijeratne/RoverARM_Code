from setuptools import find_packages, setup

package_name = 'arm_controller'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='TODO',
    maintainer_email='todo@example.com',
    description='Arm controller on the Orange Pi',
    license='TODO',
    entry_points={
        'console_scripts': [
            'controller = arm_controller.controller_node:main',
            'fake_pico = arm_controller.fake_pico:main',
        ],
    },
)
