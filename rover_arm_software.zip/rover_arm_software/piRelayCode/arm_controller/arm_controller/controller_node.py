"""Arm logic on the Orange Pi. Sits between the base station and the serial driver.

    base station --arm/joint_command (JointState)--> this node --/serial/tx (String)--> pico_relay --> Pico
    base station <--arm/pressure, arm/temperature--- this node <--/serial/rx (String)--- pico_relay <-- Pico

Commands: turns each JointState into the Pico's M line (see pico_protocol.py),
sends it only when it changes or as a 0.5 s heartbeat (at most 20 lines per
second), and sends a stop at once when the motor goes from moving to stopped.

Watchdog: the Pico has no timeout of its own, so a DC motor keeps running if
commands stop. If no joint command arrives for 0.5 s, this node sends a stop.

Sensors: the Pico prints "Temperature = ..." and "Pressure = ..." lines. They
are turned into FluidPressure (pascals) and Temperature (deg C) messages.

Run:  ros2 run arm_controller controller
"""
import math
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import FluidPressure, JointState, Temperature
from std_msgs.msg import String

from . import pico_protocol as protocol

SEND_PERIOD_S = 0.05     # check for a line to send 20 times a second
HEARTBEAT_S = 0.5        # repeat an unchanged command this often
TIMEOUT_S = 0.5          # no joint command for this long -> stop the motor


def _finite(value):
    return value is not None and math.isfinite(value)


def joint_state_to_command(msg):
    """Returns (speed_pct, servo_angles_deg) for the Pico.

    axis_0 is a DC motor, so the base station sends it as a speed: position is
    NaN and velocity is the speed as a fraction (-1 to 1). A message with no
    speed for axis_0 is refused, so an angle is never read as a motor speed.
    The other four joints are servo angles in radians, in position.
    Raises ValueError if the message is not safe to act on."""
    position = dict(zip(msg.name, msg.position))
    velocity = dict(zip(msg.name, msg.velocity))

    speed = velocity.get("axis_0")
    if not _finite(speed):
        raise ValueError("axis_0 has no speed (it is a DC motor)")
    servo_angles = []
    for name in protocol.SERVO_ORDER:
        if not _finite(position.get(name)):
            raise ValueError(f"no angle for {name}")
        servo_angles.append(math.degrees(position[name]))
    return max(-100.0, min(100.0, speed * 100.0)), servo_angles


class ArmController(Node):
    def __init__(self):
        super().__init__("arm_controller")

        # Towards the Pico (through pico_relay)
        self._tx_pub = self.create_publisher(String, "/serial/tx", 10)
        self.create_subscription(String, "/serial/rx", self.on_pico_line, 10)

        # Towards the base station
        self.create_subscription(JointState, "arm/joint_command", self.on_command, 10)
        self._pressure_pub = self.create_publisher(
            FluidPressure, "arm/pressure", qos_profile_sensor_data)
        self._temperature_pub = self.create_publisher(
            Temperature, "arm/temperature", qos_profile_sensor_data)

        self._parser = protocol.TelemetryParser()
        self._bad_lines = 0

        self._line = None              # the command line currently being sent
        self._speed = 0.0              # motor speed in that line, percent
        self._servos = None            # servo angles in that line, degrees
        self._last_sent = None
        self._last_sent_time = 0.0
        self._last_command_time = None

        self.create_timer(SEND_PERIOD_S, self.send_tick)
        self.create_timer(0.1, self.watchdog_tick)
        self.get_logger().info("Arm controller up")

    # ---- base station -> Pico
    def on_command(self, msg):
        try:
            speed, servos = joint_state_to_command(msg)
            line = protocol.encode_command(speed, servos)
        except ValueError as e:
            self.get_logger().warn(f"Rejected joint command: {e}")
            return

        now = time.monotonic()
        stopping = speed == 0.0 and self._speed != 0.0
        self._line, self._speed, self._servos = line, speed, servos
        self._last_command_time = now
        if stopping:
            self._send(line, now)      # a stop goes out at once

    def send_tick(self):
        if self._line is None:
            return
        now = time.monotonic()
        if self._line != self._last_sent or now - self._last_sent_time >= HEARTBEAT_S:
            self._send(self._line, now)

    def watchdog_tick(self):
        if self._last_command_time is None or self._speed == 0.0:
            return
        now = time.monotonic()
        if now - self._last_command_time < TIMEOUT_S:
            return
        stop = protocol.encode_command(0.0, self._servos)
        self._line, self._speed = stop, 0.0
        self._send(stop, now)
        self.get_logger().warn("No joint commands from the base station; motor stopped")

    def _send(self, line, now):
        self._tx_pub.publish(String(data=line.strip()))
        self._last_sent = line
        self._last_sent_time = now

    def stop_motor(self):
        """Best effort stop for when this node is closed."""
        if self._servos is not None:
            self._send(protocol.encode_command(0.0, self._servos), time.monotonic())

    # ---- Pico -> base station
    def on_pico_line(self, msg):
        reading = self._parser.feed(msg.data)
        if self._parser.bad > self._bad_lines:
            self._bad_lines = self._parser.bad
            self.get_logger().warn(f"Bad sensor line from Pico: '{msg.data}'")
        if reading is None:
            return

        stamp = self.get_clock().now().to_msg()
        pressure = FluidPressure()
        pressure.header.stamp = stamp
        pressure.header.frame_id = "arm_baro_link"
        pressure.fluid_pressure = reading.pressure_pa
        self._pressure_pub.publish(pressure)

        temperature = Temperature()
        temperature.header.stamp = stamp
        temperature.header.frame_id = "arm_baro_link"
        temperature.temperature = reading.temperature_c
        self._temperature_pub.publish(temperature)


def main(args=None):
    rclpy.init(args=args)
    node = ArmController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.stop_motor()
            time.sleep(0.1)            # let the stop message leave
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
