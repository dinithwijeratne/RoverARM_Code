"""A pretend Pico for testing without hardware.

Listens on /serial/tx like the serial driver would, and prints sensor text on
/serial/rx every 0.5 s the way the real Pico does. Run it INSTEAD of pico_relay:

    ros2 run arm_controller fake_pico
    ros2 run arm_controller controller
"""
import math
import time

import rclpy
from rclpy.node import Node

from std_msgs.msg import String

from . import pico_protocol as protocol


class FakePico(Node):
    def __init__(self):
        super().__init__("fake_pico")
        self._rx_pub = self.create_publisher(String, "/serial/rx", 10)
        self.create_subscription(String, "/serial/tx", self.on_line, 10)
        self.create_timer(0.5, self.print_reading)
        self._last = None
        self._start = time.monotonic()
        self.get_logger().info("Fake Pico up: listening on /serial/tx")

    def on_line(self, msg):
        try:
            cmd = protocol.parse_command(msg.data)
        except ValueError as e:
            self.get_logger().warn(f"Bad command '{msg.data}': {e}")
            return
        if cmd != self._last:                      # only print when it changes
            self._last = cmd
            direction = {0: "right", 1: "left", 2: "STOP"}[cmd.motor_dir]
            self.get_logger().info(
                f"motor pwm {cmd.motor_pwm} {direction} | servos {list(cmd.servo_deg)}")

    def print_reading(self):
        t = time.monotonic() - self._start
        temperature = 24.0 + 0.5 * math.sin(t / 20.0)
        pressure = 1013.25 + 2.0 * math.sin(t / 15.0)
        self._rx_pub.publish(String(data=f"Temperature = {temperature:.2f} *C"))
        self._rx_pub.publish(String(data=f"Pressure = {pressure:.2f} hPa"))


def main(args=None):
    rclpy.init(args=args)
    node = FakePico()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
