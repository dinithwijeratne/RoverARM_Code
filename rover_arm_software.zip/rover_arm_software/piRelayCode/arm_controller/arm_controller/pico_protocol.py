"""Serial format used by the Pico firmware. No ROS or pyserial dependency.

A copy of this file is in baseStationCode/base_station/ (used for --link serial).
If you change the format, change both.

Laptop or Pi -> Pico, one text line per command (the format the Pico code
already parses):

    M,<motor_pwm>,<motor_dir>,<S1>,<S2>,<S3>,<S4>\\n

    motor_pwm   0 to 255      speed of the axis 0 DC motor
    motor_dir   1 = left, 0 = right, 2 = force stop (brake)
    S1..S4      servo angles in degrees (whole numbers): shoulder, elbow,
                wrist, end_effector

Every command line carries all four servo angles, because the Pico moves all
servos on every line. A stop therefore repeats the last servo angles.

Pico -> laptop or Pi: the Pico prints human-readable text. Each reading
includes these two lines, which are picked out here (all other lines are ignored):

    Temperature = 24.31 *C
    Pressure = 1013.25 hPa
"""
import math
import re
from dataclasses import dataclass
from typing import Optional

JOINT_ORDER = ("axis_0", "shoulder", "elbow", "wrist", "end_effector")
SERVO_ORDER = JOINT_ORDER[1:]            # S1, S2, S3, S4

MOTOR_RIGHT = 0
MOTOR_LEFT = 1
MOTOR_STOP = 2
PWM_MAX = 255
SERVO_MIN_DEG = 0
SERVO_MAX_DEG = 300      # sanity limit only; real limits come from config/arm.yaml


class ProtocolError(ValueError):
    """A command could not be built, or a line could not be understood."""


@dataclass(frozen=True)
class PicoCommand:
    motor_pwm: int
    motor_dir: int
    servo_deg: tuple         # S1..S4, whole degrees


@dataclass(frozen=True)
class Telemetry:
    pressure_pa: float
    temperature_c: float


def motor_from_percent(speed_pct):
    """-100..100 percent -> (pwm 0..255, direction). Positive = right (0),
    negative = left (1), zero = force stop (2). If the motor turns the wrong
    way, flip `scale` for axis_0 in config/arm.yaml."""
    if not math.isfinite(speed_pct) or not -100.0 <= speed_pct <= 100.0:
        raise ProtocolError("motor speed must be between -100 and 100 percent")
    pwm = int(round(abs(speed_pct) / 100.0 * PWM_MAX))
    if pwm == 0:
        return 0, MOTOR_STOP
    return pwm, (MOTOR_RIGHT if speed_pct > 0 else MOTOR_LEFT)


def _servo_values(servo_angles_deg):
    if len(servo_angles_deg) != len(SERVO_ORDER):
        raise ProtocolError(
            f"need {len(SERVO_ORDER)} servo angles, got {len(servo_angles_deg)}")
    values = []
    for angle in servo_angles_deg:
        if not math.isfinite(angle) or not SERVO_MIN_DEG <= angle <= SERVO_MAX_DEG:
            raise ProtocolError(
                f"servo angle {angle!r} is outside {SERVO_MIN_DEG}..{SERVO_MAX_DEG}")
        values.append(int(round(angle)))
    return values


def encode_command(speed_pct, servo_angles_deg):
    """The M line for a motor speed (percent) and four servo angles (degrees)."""
    pwm, direction = motor_from_percent(speed_pct)
    servos = ",".join(str(v) for v in _servo_values(servo_angles_deg))
    return f"M,{pwm},{direction},{servos}\n"


def parse_command(line):
    """Parse and validate an M line. Used by the fake Pico and the tests.
    Raises ProtocolError for a wrong field count, non-integer fields, a pwm
    over 255 or an unknown direction."""
    parts = line.strip().split(",")
    if len(parts) != 7 or parts[0] != "M":
        raise ProtocolError("expected M plus 6 numbers")
    try:
        nums = [int(p) for p in parts[1:]]
    except ValueError:
        raise ProtocolError("fields must be whole numbers") from None
    pwm, direction, *servos = nums
    if not 0 <= pwm <= PWM_MAX:
        raise ProtocolError("motor_pwm must be 0..255")
    if direction not in (MOTOR_RIGHT, MOTOR_LEFT, MOTOR_STOP):
        raise ProtocolError("motor_dir must be 0, 1 or 2")
    return PicoCommand(pwm, direction, tuple(servos))


_NUMBER = r"(-?\d+(?:\.\d+)?)"
_TEMP = re.compile(r"^Temperature\s*=\s*" + _NUMBER + r"\s*\*?\s*C\s*$", re.IGNORECASE)
_PRESS = re.compile(r"^Pressure\s*=\s*" + _NUMBER + r"\s*hPa\s*$", re.IGNORECASE)

# Plausible limits; anything outside is treated as a bad reading.
_HPA_RANGE = (100.0, 1300.0)
_TEMP_RANGE = (-60.0, 150.0)


class TelemetryParser:
    """Feed every line the Pico prints to feed(). It returns a Telemetry once a
    Temperature line has been followed by a Pressure line, otherwise None.

    `bad` counts Temperature and Pressure lines that were malformed or out of range."""

    def __init__(self):
        self._temperature_c: Optional[float] = None
        self.bad = 0

    def feed(self, line) -> Optional[Telemetry]:
        line = line.strip()
        if line.lower().startswith("temperature"):
            match = _TEMP.match(line)
            value = float(match.group(1)) if match else None
            if value is None or not _TEMP_RANGE[0] <= value <= _TEMP_RANGE[1]:
                self.bad += 1
                self._temperature_c = None
                return None
            self._temperature_c = value
            return None
        if line.lower().startswith("pressure"):
            match = _PRESS.match(line)
            hpa = float(match.group(1)) if match else None
            if hpa is None or not _HPA_RANGE[0] <= hpa <= _HPA_RANGE[1]:
                self.bad += 1
                self._temperature_c = None
                return None
            temperature, self._temperature_c = self._temperature_c, None
            if temperature is None:
                return None              # no fresh temperature to pair it with
            return Telemetry(pressure_pa=hpa * 100.0, temperature_c=temperature)
        return None                      # altitude, "Written to SD", blank, ...
