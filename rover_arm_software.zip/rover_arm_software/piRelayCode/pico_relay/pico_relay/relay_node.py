"""Serial driver for the Pico: the USB serial connection as two ROS2 topics.

    /serial/tx  (std_msgs/String)  each message is written to the Pico as one line
    /serial/rx  (std_msgs/String)  each line the Pico prints is published here

The node knows nothing about the arm. It only moves text, so the arm logic
lives in the arm_controller package. Same idea and topic names as the example
serial node from David (github.com/ds196/two_month_rover).

Run:  ros2 run pico_relay relay
"""
import sys

import rclpy
from rclpy.node import Node

import serial
import serial.tools.list_ports

from std_msgs.msg import String

RASPBERRY_PI_VID = 0x2E8A      # every Pico shows up with this USB vendor ID


class SerialRelay(Node):
    def __init__(self):
        super().__init__("serial_relay")

        # Topics
        self._rx_pub = self.create_publisher(String, "/serial/rx", 10)
        self._tx_sub = self.create_subscription(String, "/serial/tx", self.send, 10)

        # Serial port
        self.ser = None
        self._buffer = b""
        ports = self._find_ports()
        if len(ports) == 0:
            self.get_logger().fatal("Unable to find Pico... is it plugged in?")
            sys.exit(1)
        elif len(ports) > 1:
            self.get_logger().fatal(f"Found more than one Pico {ports}... aborting.")
            sys.exit(1)
        self._open(ports[0])

        # Check for text from the Pico 50 times a second
        self.create_timer(0.02, self.read_pico)
        # If the cable is pulled, look for the Pico again once a second
        self.create_timer(1.0, self.reconnect)

    def _open(self, port):
        self.ser = serial.Serial(port, 115200, timeout=0)
        self._buffer = b""
        self.get_logger().info(f"Connected to Pico on {port}")

    def read_pico(self):
        if self.ser is None:
            return
        try:
            data = self.ser.read(self.ser.in_waiting)
        except (serial.SerialException, OSError) as e:
            self._lost(e)
            return
        if not data:
            return

        self._buffer += data
        while b"\n" in self._buffer:
            raw, self._buffer = self._buffer.split(b"\n", 1)
            try:
                text = raw.decode("utf8").strip()
            except UnicodeDecodeError as e:
                self.get_logger().warn(f"Ignoring invalid unicode from Pico: {e}")
                continue
            if text:
                self._rx_pub.publish(String(data=text))
        if len(self._buffer) > 4096:       # no newline for ages: throw it away
            self._buffer = b""

    def send(self, msg):
        if self.ser is None:
            self.get_logger().warn("Pico not connected, command dropped",
                                   throttle_duration_sec=5.0)
            return
        line = msg.data.strip() + "\n"
        try:
            self.ser.write(line.encode("utf8"))
        except (serial.SerialException, OSError) as e:
            self._lost(e)

    def _lost(self, error):
        self.get_logger().error(f"Lost the Pico: {error}")
        try:
            self.ser.close()
        except Exception:
            pass
        self.ser = None

    def reconnect(self):
        if self.ser is not None:
            return
        ports = self._find_ports()
        if len(ports) == 1:
            try:
                self._open(ports[0])
            except (serial.SerialException, OSError) as e:
                self.get_logger().warn(f"Could not open {ports[0]}: {e}",
                                       throttle_duration_sec=10.0)

    def _find_ports(self):
        """Serial ports of every connected Pico."""
        return [p.device for p in serial.tools.list_ports.comports()
                if p.vid == RASPBERRY_PI_VID and p.device is not None]


def main(args=None):
    rclpy.init(args=args)
    node = SerialRelay()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
