from setuptools import find_packages, setup

package_name = 'pico_relay'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='TODO',
    maintainer_email='todo@example.com',
    description='Serial driver for the Pico',
    license='TODO',
    entry_points={
        'console_scripts': [
            'relay = pico_relay.relay_node:main',
        ],
    },
)
